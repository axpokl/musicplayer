﻿# musicplayer
一款基于Un4senn BASS的Pascal音乐播放器

Drag file to play. Support command line to play. 
Support wav,mp3,ogg,wma,ape,flac,mod & mid file. 

MLeft	Jump
MRight	Pause
MWheel	Volume

Left	Backward
Right	Forward
Up	Volumn+
Down	Volume-
Space	Pause

PGUp	Next
PGDown	Prev
Home	First
End	Last

+/-	Speed
[/]	Pitch
Num+/-	Freq

F1	Help
F2	Hanning
F3/F4	Line
F5/F6	Color
F7/F8	FPS
F11     Chord
F12	Loop